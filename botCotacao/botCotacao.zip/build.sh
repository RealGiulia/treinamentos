#!/bin/bash

zip -r "botCotacao.zip" * -x "botCotacao.zip"
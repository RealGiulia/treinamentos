#!/bin/bash

zip -r "botSnow.zip" * -x "botSnow.zip"
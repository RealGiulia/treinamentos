#!/bin/bash

zip -r "botFakturama.zip" * -x "botFakturama.zip"